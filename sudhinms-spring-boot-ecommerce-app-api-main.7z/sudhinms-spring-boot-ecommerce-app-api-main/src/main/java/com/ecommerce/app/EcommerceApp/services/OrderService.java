package com.ecommerce.app.EcommerceApp.services;

import com.ecommerce.app.EcommerceApp.controllers.AdminController;
import com.ecommerce.app.EcommerceApp.controllers.CustomerController;
import com.ecommerce.app.EcommerceApp.controllers.HomeController;
import com.ecommerce.app.EcommerceApp.dto.paymentsDto.PaymentDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.OrderDetailDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.UpdateOrderDetailsDto;
import com.ecommerce.app.EcommerceApp.dto.userDto.UserDetailsAdminView;
import com.ecommerce.app.EcommerceApp.entities.*;
import com.ecommerce.app.EcommerceApp.enums.OrderStatus;
import com.ecommerce.app.EcommerceApp.enums.PaymentStatus;
import com.ecommerce.app.EcommerceApp.exceptions.*;
import com.ecommerce.app.EcommerceApp.repositories.*;
import com.ecommerce.app.EcommerceApp.services.paymentServices.PaymentService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.random.RandomGenerator;


@Service
@Slf4j
public class OrderService {

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private CartDetailsRepository cartDetailsRepository;

    private PaymentService paymentService;
//    private final HashMap<String,Long> userOrderInfoMap=new HashMap<>();

    private long getUserIdWithEmail(String email){
        UserInfo userInfo=userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("user with email : "+email+" not found"));
        return userInfo.getId();
    }

    private ProductDetails checkQuantity(long productId){
        ProductDetails productDetails=productRepository.findById(productId)
                .orElseThrow(()->new ProductNotFoundException("Product with id : "+productId+" not found"));
        if(productDetails.getQuantity()<=0){
            throw new ProductOutOfStockException("product is out of stock..");
        }
        return productDetails;
    }

//    public ResponseEntity<?> initiateOrdering(String email,long productId,int quantity){
//        checkQuantity(productId);
//        List<Address> addresses= addressRepository.findByUserInfoId(getUserIdWithEmail(email))
//                .orElseThrow(()->new AddressNotFoundException("You don't have a valid address..."));
//        CollectionModel<Address> collectionModel=CollectionModel.of(addresses);
//        ProductDetails productDetails=checkQuantity(productId);
//        HttpStatus httpStatus=HttpStatus.OK;
//        if(productDetails.getQuantity()<quantity){
//            throw new ProductOutOfStockException("Couldn't place order. Only "+productDetails.getQuantity()+" left!!!");
//        }
//        if(!addresses.isEmpty()){
//            collectionModel.add(Link.of("http://localhost:8081/app/product/order/confirm-address/{addressId}"));
//        }
//        else {
//            collectionModel.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(HomeController.class)
//                    .createAddress(null, null)).withRel("Create_New_Address"));
//            httpStatus=HttpStatus.CONTINUE;
//        }
//        this.userOrderInfoMap.put("productId",productId);
//        this.userOrderInfoMap.put("quantity", (long) quantity);
//        return new ResponseEntity<>(collectionModel,httpStatus);
//    }

    public ResponseEntity<?> initiateOrdering(String email,long productId,int quantity){
        checkQuantity(productId);
        List<Address> addresses= addressRepository.findByUserInfoId(getUserIdWithEmail(email))
                .orElseThrow(()->new AddressNotFoundException("You don't have a valid address..."));
        CollectionModel<Address> collectionModel=CollectionModel.of(addresses);
        ProductDetails productDetails=checkQuantity(productId);
        HttpStatus httpStatus=HttpStatus.OK;
        if(productDetails.getQuantity()<quantity){
            throw new ProductOutOfStockException("Couldn't place order. Only "+productDetails.getQuantity()+" left!!!");
        }
        Orders order=new Orders();
        order.setQuantity(quantity);
        order.setProductDetails(productDetails);
        double totalPrice=(productDetails.getPrice())*quantity;
        order.setTotalPrice(totalPrice);
        UserInfo userInfo=userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("user with email : "+email+" not found"));
        order.setUserInfo(userInfo);
        order.setStatus(OrderStatus.ORDER_INITIATED.name());

        order.setPaymentStatus(PaymentStatus.NOT_PAYED.name());
        orderRepository.save(order);
        if(!addresses.isEmpty()){
            collectionModel.add(Link.of("http://localhost:8081/app/product/order/confirm-address/{addressId}"));
        }
        else {
            collectionModel.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(HomeController.class)
                    .createAddress(null, null)).withRel("Create_New_Address"));
            httpStatus=HttpStatus.CONTINUE;
        }
        return new ResponseEntity<>(collectionModel,httpStatus);
    }

    public ResponseEntity<?> confirmAddress(long addressId,String email){
        Address address=addressRepository.findById(addressId)
                .orElseThrow(()->new AddressNotFoundException("You don't have a valid address..."));
        List<Orders> initiatedOrders=null;
        if(address==null){
            throw new AddressNotFoundException("You don't have a valid address...");
        }
//            this.userOrderInfoMap.put("addressId",addressId);
            List<Orders> orders=orderRepository.findByUserInfoId(getUserIdWithEmail(email));
        if(orders.isEmpty()){
            return new ResponseEntity<>(EntityModel.of("Create a order")
                    .add(Link.of("http://localhost:8081/app/product/order/create-order/{productId}/{quantity}"))
                    ,HttpStatus.CONFLICT);
        }
            initiatedOrders=orders.stream()
                    .filter(order -> Objects.equals(order.getStatus(), OrderStatus.ORDER_INITIATED.name()))
                    .peek(order-> order.setAddress(address))
                    .toList();
        EntityModel<List<Orders>> entityModel=EntityModel.of(initiatedOrders);
        entityModel.add(Link.of("http://localhost:8081/app/product/order/payment/upi/{orderId}"));
        entityModel.add(Link.of("http://localhost:8081/app/product/order/payment/cash-on-delivery/{orderId}"));
        return new ResponseEntity<>(entityModel,HttpStatus.OK);
    }

//    public ResponseEntity<EntityModel<String>> choosePaymentMethod(){
//        Link link1=Link.of("http://localhost:8081/app/product/order/payment/upi/{productId}/{quantity}");
//        Link link2=Link.of("http://localhost:8081/app/product/order/payment/cash-on-delivery/{productId}/{quantity}");
//        EntityModel<String> entityModel=EntityModel.of("Choose payment link");
//        entityModel.add(link1.withRel("UPI_Payment"));
//        entityModel.add(link2.withRel("Cash_On_Delivery"));
//        return new ResponseEntity<>(entityModel,HttpStatus.OK);
//    }

//    public ResponseEntity<?> upiPayment(PaymentDto paymentDto,String email,long productId,int quantity){
//        this.paymentService=new UpiPayment();
//        userOrderInfoMap.put("productId",productId);
//        userOrderInfoMap.put("quantity", (long) quantity);
//        PaymentDto paymentDto1=paymentService.doPayment(userOrderInfoMap,paymentDto);
//        return confirmOrder(email,userOrderInfoMap, PaymentStatus.PAYED.name());
//    }

    public ResponseEntity<?> upiPayment(String email,long orderId,PaymentDto paymentDto){
//        this.paymentService=new UpiPayment();
//        HashMap<String,Long> userOrderInfoMap=new HashMap<>();
//        String paymentNumber="UPI"+ Random
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->new InvalidOrderDetailsException("Order with id : "+orderId+" not found"));
        order.setStatus(OrderStatus.ORDER_PLACED.name());
        order.setPaymentStatus(PaymentStatus.PAYED.name());
        return confirmOrder(email,order);
    }
    public ResponseEntity<?> cashOnDeliveryPayment(String email,long orderId){
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->new InvalidOrderDetailsException("Order with id : "+orderId+" not found"));
        order.setPaymentStatus(PaymentStatus.CASH_ON_DELIVERY.name());
        return confirmOrder(email,order);
    }

//    private ResponseEntity<?> confirmOrder(String email, HashMap<String,Long> userOrderInfoMap,String paymentStatus) {
//        UserInfo userInfo = userRepository.findByEmail(email)
//                .orElseThrow(()->new UsernameNotFoundException("User not found with username : "+email));
//        Address address=addressRepository.findById(userOrderInfoMap.get("addressId"))
//                .orElseThrow(()->new AddressNotFoundException("You don't have a valid address..."));
//        if(userInfo.getId()!=address.getUserInfo().getId()){
//            throw new AddressNotFoundException("Invalid address id");
//        }
//        ProductDetails productDetails=productRepository.findById(userOrderInfoMap.get("productId"))
//                .orElseThrow(()->new ProductNotFoundException("product not found"));
//
//        Orders orders=new Orders();
//        orders.setOrderDateTime(LocalDateTime.now());
//        orders.setQuantity(Math.toIntExact(userOrderInfoMap.get("quantity")));
//        orders.setAddressId(userOrderInfoMap.get("addressId"));
//        orders.setUserInfo(userRepository.findByEmail(email).get());
//        orders.setExpectedDeliveryDate(Date.from((orders.getOrderDateTime().plusDays(7))
//                .atZone(ZoneId.systemDefault()).toInstant()));
//        orders.setPaymentStatus(paymentStatus);
//        orders.setStatus(OrderStatus.ORDER_PLACED.name());
//        orders.setProductDetails(productDetails);
//        double total=userOrderInfoMap.get("quantity")*orders.getProductDetails().getPrice();
//        orders.setTotalPrice(total);
//        Orders savedOrder=orderRepository.save(orders);
//        productDetails.setQuantity((productDetails.getQuantity())-(orders.getQuantity()));
//        productRepository.save(productDetails);
//        return getAllOrdersOfUser(email);
//    }
    private ResponseEntity<?> confirmOrder(String email, Orders order) {
        UserInfo userInfo = userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("User not found with username : "+email));
        Address address=addressRepository.findById(order.getAddress().getId())
                .orElseThrow(()->new AddressNotFoundException("You don't have a valid address..."));
        if(userInfo.getId()!=address.getUserInfo().getId()){
            throw new AddressNotFoundException("Invalid address id");
        }
        ProductDetails productDetails=productRepository.findById(order.getProductDetails().getId())
                .orElseThrow(()->new ProductNotFoundException("product not found"));
        orderRepository.save(order);
        productDetails.setQuantity((productDetails.getQuantity())-(order.getQuantity()));
        productRepository.save(productDetails);
        return getAllOrdersOfUser(email);
    }


    public ResponseEntity<CollectionModel<Orders>> getAllOrdersOfUser(String email) {
        UserInfo userInfo=userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("Users not found with username : "+email));
        List<Orders> ordersList=orderRepository.findByUserInfoId(userInfo.getId());
        if(ordersList.isEmpty()){
            throw new InvalidOrderDetailsException("no order found for user : "+email);
        }
        CollectionModel<Orders> collectionModel=CollectionModel.of(ordersList);
        Link link=Link.of("http://localhost:8081/app/product/order/{orderId}");
        collectionModel.add(link.withRel("Single_order_details"));
        return new ResponseEntity<>(collectionModel,HttpStatus.OK);
    }

    public ResponseEntity<?> getAllUserOrder() {
        return new ResponseEntity<>(orderRepository.findAll(),HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<?> updateOrderDetails(long orderId, UpdateOrderDetailsDto orderDetailsDto) {
            Orders orders = orderRepository.findById(orderId)
                    .orElseThrow(() -> new InvalidOrderDetailsException("Order with id : " + orderId + " not found"));
            if (orders != null) {
                if (orderDetailsDto.getExpectedDeliveryDate() != null) {
                    orders.setExpectedDeliveryDate(orderDetailsDto.getExpectedDeliveryDate());
                }
                if (orderDetailsDto.getStatus() != null) {
                    try {
                        orders.setStatus(OrderStatus.valueOf(orderDetailsDto.getStatus()).name());
                    } catch (IllegalArgumentException e) {
                        throw new IllegalArgumentException("Illegal argument for field 'status'");
                    }
                }
                orders = orderRepository.save(orders);
            }
        assert orders != null;
        EntityModel<Orders> entityModel = EntityModel.of(orders);
            entityModel.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AdminController.class)
                    .getAllOrders()).withRel("All_Orders"));
            return new ResponseEntity<>(entityModel, HttpStatus.ACCEPTED);
    }

    public ResponseEntity<OrderDetailDto> getSingleOrder(long orderId) {
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->new InvalidOrderDetailsException("No order found with id : "+orderId));
        if(order==null){
            throw new InvalidOrderDetailsException("Order not found with id : "+orderId);
        }
        OrderDetailDto orderDetailDto=new OrderDetailDto();
        orderDetailDto.setId(order.getId());
        orderDetailDto.setOrderDateTime(order.getOrderDateTime());
        orderDetailDto.setExpectedDeliveryDate(order.getExpectedDeliveryDate());
        orderDetailDto.setQuantity(order.getQuantity());
        Optional<Address> address=addressRepository.findById(order.getAddress().getId());
        address.ifPresent(orderDetailDto::setAddress);
        orderDetailDto.setStatus(order.getStatus());
        UserInfo userInfo=userRepository.findById(order.getUserInfo().getId())
                .orElseThrow(()->new UsernameNotFoundException("No user found"));
        UserDetailsAdminView userDetailsAdminView=new UserDetailsAdminView();
        userDetailsAdminView.setEmail(userInfo.getEmail());
        userDetailsAdminView.setName(userInfo.getName());
        userDetailsAdminView.setMobile(userInfo.getMobile());
        if(userInfo.getProfileImage()!=null){
            userDetailsAdminView.setProfileImage(userInfo.getProfileImage());
        }
        orderDetailDto.setUserDetails(userDetailsAdminView);
        Optional<ProductDetails> productDetails=productRepository.findById(order.getProductDetails().getId());
        productDetails.ifPresent(orderDetailDto::setProductDetails);

        return new ResponseEntity<>(orderDetailDto,HttpStatus.OK);
    }

    public ResponseEntity<?> returnProduct(long orderId, String email) {
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->
                        new InvalidOrderDetailsException("Order with order id : "+orderId+" not found"));
        if(!Objects.equals(order.getUserInfo().getEmail(), email)){
            throw new InvalidOrderDetailsException("user '"+email+"' have no order with order id "+orderId);
        }
        String message=null;
        HttpStatus httpStatus=HttpStatus.BAD_REQUEST;
        switch (OrderStatus.valueOf(order.getStatus())){
            case RETURNED:
                throw new ProductDeliveryException("Can't initiate return request because product is already returned");
            case RETURN_REQUEST:
                throw new ProductDeliveryException("Can't initiate return request because product is already requested to return");
            case DELIVERED:
                order.setStatus(OrderStatus.RETURN_REQUEST.name());
                orderRepository.save(order);
                message="Return request initiated successfully";
                httpStatus=HttpStatus.OK;
                break;
            default:
                message="Order is not in a state for return!!!";
                break;
        }
        Link link=WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                .getAllOrders("")).withRel("All_Orders");
        EntityModel<String> entityModel=EntityModel.of(message);
        entityModel.add(link);
        return  new ResponseEntity<>(entityModel,httpStatus);
    }

    public ResponseEntity<EntityModel<String>> cancelOrder(long orderId, String email){
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->
                        new InvalidOrderDetailsException("Order with order id : "+orderId+" not found"));
        if(!Objects.equals(order.getUserInfo().getEmail(), email)){
            throw new InvalidOrderDetailsException("user '"+email+"' have no order with order id "+orderId);
        }
        String message=null;
        Link link=WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                .getAllOrders("")).withRel("All_Orders");
        HttpStatus httpStatus=HttpStatus.BAD_REQUEST;
        Link.of("http://localhost:8081/app/product/order/return-order/{orderId}");

        switch (OrderStatus.valueOf(order.getStatus())){

            case DELIVERED:
                message="Can't cancel order because product is delivered.You can request to return product";
                link=Link.of("http://localhost:8081/app/product/order/return-order/{orderId}");
                break;
            case OUT_FOR_DELIVERY:
                message="Can't cancel order because product is out for delivered.You can request to return product when you get it";
                link=Link.of("http://localhost:8081/app/product/order/return-order/{orderId}");
                break;
            case CANCELLED:
                message="Can't cancel order because product is already cancelled";
                break;
            case RETURN_REQUEST:
                throw new ProductDeliveryException("Can't initiate cancel request because product is in return state");
            case RETURNED:
                throw new ProductDeliveryException("Can't initiate cancel request because product is already returned");
            default:
                message="Cancel request initiated successfully";
                order.setStatus(OrderStatus.CANCELLED.name());
                orderRepository.save(order);
                httpStatus=HttpStatus.OK;
                break;
        }
        return new ResponseEntity<>(EntityModel.of(message).add(link),httpStatus);
    }

    public void checkoutAllProductsInCart(String email) {
        List<CartDetails> allProducts = cartDetailsRepository.findAllByUserId(getUserIdWithEmail(email));
        if (allProducts.isEmpty()) {
            throw new ProductNotFoundException("No items in your cart");
        }
//        for(int i=0;i<)
    }
}
