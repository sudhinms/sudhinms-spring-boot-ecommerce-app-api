package com.ecommerce.app.EcommerceApp.repositories;

import com.ecommerce.app.EcommerceApp.entities.Orders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Orders,Long> {
//    Optional<List<Orders>> findByUserInfoId(Long userId);
//    Optional<List<Orders>> findByUserId(long id);
    List<Orders> findByUserInfoId(Long userId);

    @Modifying
    @Query("DELETE FROM Orders o WHERE o.status = :orderStatus AND o.orderDateTime <= :expirationTime")
    void deleteByOrderStatusAndOrderedTimeBefore(@Param("orderStatus") String orderStatus, @Param("expirationTime") LocalDateTime expirationTime);

}
