package com.ecommerce.app.EcommerceApp.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER;
}
