package com.ecommerce.app.EcommerceApp.services;

import com.ecommerce.app.EcommerceApp.controllers.AdminController;
import com.ecommerce.app.EcommerceApp.controllers.CustomerController;
import com.ecommerce.app.EcommerceApp.dto.paymentsDto.PaymentDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.OrderDetailDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.ProductDetailsDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.UpdateOrderDetailsDto;
import com.ecommerce.app.EcommerceApp.dto.userDto.UserDetailsAdminView;
import com.ecommerce.app.EcommerceApp.entities.*;
import com.ecommerce.app.EcommerceApp.enums.OrderStatus;
import com.ecommerce.app.EcommerceApp.enums.PaymentStatus;
import com.ecommerce.app.EcommerceApp.exceptions.*;
import com.ecommerce.app.EcommerceApp.repositories.*;
import com.ecommerce.app.EcommerceApp.services.paymentServices.PaymentService;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.*;
import java.sql.Date;
import java.util.stream.Collectors;


@Service
@Slf4j
public class OrderService {

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private AddressRepository addressRepository;
    @Autowired
    private CartDetailsRepository cartDetailsRepository;

    private PaymentService paymentService;

    private long getUserIdWithEmail(String email){
        UserInfo userInfo=userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("user with email : "+email+" not found"));
        return userInfo.getId();
    }

    private ProductDetails checkQuantity(long productId){
        ProductDetails productDetails=productRepository.findById(productId)
                .orElseThrow(()->new ProductNotFoundException("Product with id : "+productId+" not found"));
        if(productDetails.getQuantity()<=0){
            throw new ProductOutOfStockException("product is out of stock..");
        }
        return productDetails;
    }
    private byte[] getImage(String imagePath){
        if(Files.exists(Path.of(imagePath))){
            try {
                return Files.readAllBytes(Path.of(imagePath));
            } catch (IOException e) {
                return null;
            }
        }
        return new byte[]{};
    }

    private void saveOrderDetails(String email,long productId,int quantity){
        UserInfo userInfo=userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("user with email : "+email+" not found"));
        ProductDetails productDetails=checkQuantity(productId);
        if(productDetails.getQuantity()<quantity){
            throw new ProductOutOfStockException("Couldn't place order. Only "+productDetails.getQuantity()+" left!!!");
        }
        Orders order=new Orders();
        order.setQuantity(quantity);
        order.setProductDetails(productDetails);
        double totalPrice=(productDetails.getPrice())*quantity;
        order.setTotalPrice(totalPrice);
        order.setUserInfo(userInfo);
        order.setOrderDateTime(LocalDateTime.now());
        Date date=Date.valueOf(order.getOrderDateTime().plusDays(7).toLocalDate());
        order.setExpectedDeliveryDate(date);
        order.setStatus(OrderStatus.ORDER_INITIATED.name());
        order.setPaymentStatus(PaymentStatus.NOT_PAYED.name());
        orderRepository.save(order);
    }

    private ResponseEntity<?> initiateOrdering(String email){
        List<Address> addressList = addressRepository.findByUserInfoId(getUserIdWithEmail(email)).get();

        if(addressList.isEmpty()){
            throw new AddressNotFoundException("No address found for your account");
        }
        List<EntityModel<Address>> entityModelList=null;
        CollectionModel<EntityModel<Address>> collectionModel=null;
        entityModelList=addressList.stream()
                   .map(EntityModel::of)
                   .toList();
        collectionModel=CollectionModel.of(entityModelList);
        collectionModel=collectionModel
                .add(Link.of("http://localhost:8081/app/home/order/confirm-address/{addressId}")
                .withRel("Choose_addressID"));
        return ResponseEntity.status(HttpStatus.OK).body(collectionModel);
    }



    public ResponseEntity<CollectionModel<EntityModel<OrderDetailDto>>> confirmAddress(long addressId, String email) {
        Address address = addressRepository.findById(addressId)
                .orElseThrow(() -> new AddressNotFoundException("You don't have a valid address..."));
        if (address == null) {
            throw new AddressNotFoundException("You don't have a valid address...");
        }
        List<Orders> orders = orderRepository.findByUserInfoId(getUserIdWithEmail(email));
        List<OrderDetailDto> initiatedOrder = orders
                .stream()
                .filter(order ->
                        Objects.equals(order.getStatus(), "ORDER_INITIATED") && Objects.equals(order.getPaymentStatus(), "NOT_PAYED"))
                .map(order -> {
                    order.setAddress(address);
                    Orders savedOrder = orderRepository.save(order);
                    return orderDetailDtoMapper(savedOrder);
                })
                .toList();
        List<EntityModel<OrderDetailDto>> entityModelList = initiatedOrder
                .stream()
                .map(EntityModel::of)
                .collect(Collectors.toList());
        CollectionModel<EntityModel<OrderDetailDto>> collectionModel = CollectionModel.of(entityModelList);
        collectionModel=collectionModel.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                .initiateUpiPayment("",null)).withRel("UPI_Payment"));
        collectionModel=collectionModel.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                .initiateCashOnDelivery("",null)).withRel("UPI_Payment"));
        return new ResponseEntity<>(collectionModel, HttpStatus.OK);
    }



    public ResponseEntity<?> orderSingleItem(String email,long productId,int quantity){
        saveOrderDetails(email,productId,quantity);
        return initiateOrdering(email);
    }
    public ResponseEntity<?> checkoutAllProductsInCart(String email) {
        List<CartDetails> allProducts = cartDetailsRepository.findAllByUserId(getUserIdWithEmail(email));
        if (allProducts.isEmpty()) {
            throw new ProductNotFoundException("No items in your cart");
        }
        allProducts.forEach(product->saveOrderDetails(email, product.getProductId(),product.getQuantity()));
        return initiateOrdering(email);
    }

    private ResponseEntity<?> confirmOrder(String email, List<Orders> allOrders) {
        UserInfo userInfo = userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("User not found with username : "+email));
        allOrders.forEach(order -> {
            Address address=addressRepository.findById(order.getAddress().getId())
                    .orElseThrow(()->new AddressNotFoundException("You don't have a valid address..."));
            if(userInfo.getId()!=address.getUserInfo().getId()){
                throw new AddressNotFoundException("Invalid address id");
            }
            ProductDetails productDetails=productRepository.findById(order.getProductDetails().getId())
                    .orElseThrow(()->new ProductNotFoundException("product not found"));
            orderRepository.save(order);
            productDetails.setQuantity((productDetails.getQuantity())-(order.getQuantity()));
            productRepository.save(productDetails);
        });
        return getAllOrdersOfUser(email);
    }

    public ResponseEntity<?> upiPayment(String email,PaymentDto paymentDto){
        List<Orders> allOrders=orderRepository
                .findByUserInfoIdAndStatus(getUserIdWithEmail(email),"ORDER_INITIATED");
        List<Orders> updatedOrders=allOrders.stream().map(order -> {
            order.setStatus(OrderStatus.ORDER_PLACED.name());
            order.setPaymentStatus(PaymentStatus.PAYED.name());
            return order;
        }).toList();

        return confirmOrder(email,updatedOrders);
    }
    public ResponseEntity<?> cashOnDeliveryPayment(String email,List<Long> orderIds){
        List<Orders> updatedOrders=orderIds.stream().map(orderId->{
            Orders order=orderRepository.findById(orderId)
                    .orElseThrow(()->new InvalidOrderDetailsException("Order with id : "+orderId+" not found"));
            order.setPaymentStatus(PaymentStatus.CASH_ON_DELIVERY.name());
            return order;
        }).toList();
        return confirmOrder(email,updatedOrders);
    }

    public ResponseEntity<?> getAllOrdersOfUser(String email) {
        UserInfo userInfo=userRepository.findByEmail(email)
                .orElseThrow(()->new UsernameNotFoundException("Users not found with username : "+email));
        List<Orders> ordersList=orderRepository.findByUserInfoId(userInfo.getId());
        List<OrderDetailDto> orderDetailDtoList=ordersList.stream().map(orders ->orderDetailDtoMapper(orders)).toList();
        List<EntityModel<OrderDetailDto>> entityModelList=orderDetailDtoList
                .stream()
                .map(EntityModel::of)
                .toList();
        if(ordersList.isEmpty()){
            throw new InvalidOrderDetailsException("no order found for user : "+email);
        }
        CollectionModel<EntityModel<OrderDetailDto>> collectionModel=CollectionModel.of(entityModelList);
        Link link=Link.of("http://localhost:8081/app/product/order/{orderId}");
        collectionModel.add(link.withRel("Single_order_details"));
        return new ResponseEntity<>(orderDetailDtoList,HttpStatus.OK);
    }

    private OrderDetailDto orderDetailDtoMapper(Orders order){
        OrderDetailDto orderDetailDto=new OrderDetailDto();
        orderDetailDto.setId(order.getId());
        orderDetailDto.setOrderDateTime(order.getOrderDateTime());
        orderDetailDto.setExpectedDeliveryDate(order.getExpectedDeliveryDate());
        orderDetailDto.setQuantity(order.getQuantity());
        orderDetailDto.setAddress(order.getAddress());
        orderDetailDto.setStatus(order.getStatus());
        UserInfo userInfo=userRepository.findById(order.getUserInfo().getId())
                .orElseThrow(()->new UsernameNotFoundException("No user found"));
        if (userInfo == null) {
            throw new UsernameNotFoundException("No user found");
        }
        UserDetailsAdminView userDetailsAdminView=new UserDetailsAdminView();
        userDetailsAdminView.setEmail(userInfo.getEmail());
        userDetailsAdminView.setName(userInfo.getName());
        userDetailsAdminView.setMobile(userInfo.getMobile());
        if(userInfo.getProfileImage()!=null){
            userDetailsAdminView.setProfileImage(userInfo.getProfileImage());
        }
        orderDetailDto.setUserDetails(userDetailsAdminView);
        ProductDetails productDetails=productRepository.findById(order.getProductDetails().getId())
                .orElseThrow(()->new ProductNotFoundException("Product not found"));
        ProductDetailsDto productDetailsDto=new ProductDetailsDto();
        productDetailsDto.setId(productDetails.getId());
        productDetailsDto.setName(productDetails.getName());
        productDetailsDto.setBrand(productDetails.getBrand());
        productDetailsDto.setQuantity(order.getQuantity());
        productDetailsDto.setPrice(productDetails.getPrice());
        productDetailsDto.setCategory(productDetails.getCategory().getName());
        if(productDetails.getImagePath()!=null){
            productDetailsDto.setProductImage(getImage(productDetails.getImagePath()));
        }
        System.out.println(productDetailsDto.getCategory());
        orderDetailDto.setProductDetails(productDetailsDto);
        return orderDetailDto;
    }

    public ResponseEntity<?> getAllUserOrder() {
        return new ResponseEntity<>(orderRepository.findAll(),HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<?> updateOrderDetails(long orderId, UpdateOrderDetailsDto orderDetailsDto) {
            Orders orders = orderRepository.findById(orderId)
                    .orElseThrow(() -> new InvalidOrderDetailsException("Order with id : " + orderId + " not found"));
            if (orders != null) {
                if (orderDetailsDto.getExpectedDeliveryDate() != null) {
                    orders.setExpectedDeliveryDate((Date) orderDetailsDto.getExpectedDeliveryDate());
                }
                if (orderDetailsDto.getStatus() != null) {
                    try {
                        orders.setStatus(OrderStatus.valueOf(orderDetailsDto.getStatus()).name());
                    } catch (IllegalArgumentException e) {
                        throw new IllegalArgumentException("Illegal argument for field 'status'");
                    }
                }
                orders = orderRepository.save(orders);
            }
        assert orders != null;
        EntityModel<Orders> entityModel = EntityModel.of(orders);
            entityModel.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AdminController.class)
                    .getAllOrders()).withRel("All_Orders"));
            return new ResponseEntity<>(entityModel, HttpStatus.ACCEPTED);
    }

    public ResponseEntity<OrderDetailDto> getSingleOrder(long orderId) {
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->new InvalidOrderDetailsException("No order found with id : "+orderId));
        if(order==null){
            throw new InvalidOrderDetailsException("Order not found with id : "+orderId);
        }

        return new ResponseEntity<>(orderDetailDtoMapper(order),HttpStatus.OK);
    }

    public ResponseEntity<?> returnProduct(long orderId, String email) {
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->
                        new InvalidOrderDetailsException("Order with order id : "+orderId+" not found"));
        if(!Objects.equals(order.getUserInfo().getEmail(), email)){
            throw new InvalidOrderDetailsException("user '"+email+"' have no order with order id "+orderId);
        }
        String message=null;
        HttpStatus httpStatus=HttpStatus.BAD_REQUEST;
        switch (OrderStatus.valueOf(order.getStatus())){
            case RETURNED:
                throw new ProductDeliveryException("Can't initiate return request because product is already returned");
            case RETURN_REQUEST:
                throw new ProductDeliveryException("Can't initiate return request because product is already requested to return");
            case DELIVERED:
                order.setStatus(OrderStatus.RETURN_REQUEST.name());
                orderRepository.save(order);
                message="Return request initiated successfully";
                httpStatus=HttpStatus.OK;
                break;
            default:
                message="Order is not in a state for return!!!";
                break;
        }
        Link link=WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                .getAllOrders("")).withRel("All_Orders");
        EntityModel<String> entityModel=EntityModel.of(message);
        entityModel.add(link);
        return  new ResponseEntity<>(entityModel,httpStatus);
    }

    public ResponseEntity<EntityModel<String>> cancelOrder(long orderId, String email){
        Orders order=orderRepository.findById(orderId)
                .orElseThrow(()->
                        new InvalidOrderDetailsException("Order with order id : "+orderId+" not found"));
        if(!Objects.equals(order.getUserInfo().getEmail(), email)){
            throw new InvalidOrderDetailsException("user '"+email+"' have no order with order id "+orderId);
        }
        String message=null;
        Link link=WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                .getAllOrders("")).withRel("All_Orders");
        HttpStatus httpStatus=HttpStatus.BAD_REQUEST;
        Link.of("http://localhost:8081/app/product/order/return-order/{orderId}");

        switch (OrderStatus.valueOf(order.getStatus())){

            case DELIVERED:
                message="Can't cancel order because product is delivered.You can request to return product";
                link=Link.of("http://localhost:8081/app/product/order/return-order/{orderId}");
                break;
            case OUT_FOR_DELIVERY:
                message="Can't cancel order because product is out for delivered.You can request to return product when you get it";
                link=Link.of("http://localhost:8081/app/product/order/return-order/{orderId}");
                break;
            case CANCELLED:
                message="Can't cancel order because product is already cancelled";
                break;
            case RETURN_REQUEST:
                throw new ProductDeliveryException("Can't initiate cancel request because product is in return state");
            case RETURNED:
                throw new ProductDeliveryException("Can't initiate cancel request because product is already returned");
            default:
                message="Cancel request initiated successfully";
                order.setStatus(OrderStatus.CANCELLED.name());
                orderRepository.save(order);
                httpStatus=HttpStatus.OK;
                break;
        }
        return new ResponseEntity<>(EntityModel.of(message).add(link),httpStatus);
    }

}
