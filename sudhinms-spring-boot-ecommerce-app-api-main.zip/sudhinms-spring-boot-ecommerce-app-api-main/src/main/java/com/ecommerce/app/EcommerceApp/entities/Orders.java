package com.ecommerce.app.EcommerceApp.entities;

import jakarta.persistence.*;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Past;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Date;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Entity
@ToString
public class Orders {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private LocalDateTime orderDateTime;
    @Future(message = "Date must be in the past")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private Date expectedDeliveryDate;
    @Min(value = 1)
    private int quantity;
    @ManyToOne
    @JoinColumn(name = "address_id")
    private Address address;
    private String status;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private UserInfo userInfo;
    @ManyToOne
    @JoinColumn(name = "product_id")
    private ProductDetails productDetails;
    private String paymentStatus;
    private double totalPrice;
    private String paymentNumber;
}
