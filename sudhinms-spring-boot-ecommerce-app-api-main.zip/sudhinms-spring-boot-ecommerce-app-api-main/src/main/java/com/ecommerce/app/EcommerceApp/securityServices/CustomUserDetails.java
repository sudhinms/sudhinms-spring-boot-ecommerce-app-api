package com.ecommerce.app.EcommerceApp.securityServices;

import com.ecommerce.app.EcommerceApp.entities.UserInfo;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class CustomUserDetails implements UserDetails {
    private String email;
    private String password;
    private List<GrantedAuthority> authorityList;

    public CustomUserDetails(UserInfo userInfo) {
        this.email=userInfo.getEmail();
        this.password=userInfo.getPassword();
        this.authorityList= new ArrayList<>();
        authorityList.add(new SimpleGrantedAuthority(userInfo.getRole()));

    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return this.authorityList;
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
