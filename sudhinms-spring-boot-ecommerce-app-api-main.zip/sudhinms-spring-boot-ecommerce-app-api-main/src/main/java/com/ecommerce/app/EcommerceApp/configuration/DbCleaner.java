package com.ecommerce.app.EcommerceApp.configuration;

import com.ecommerce.app.EcommerceApp.repositories.OrderRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class DbCleaner {
    @Autowired
    private OrderRepository orderRepository;

    @Scheduled(cron = "0 0 */2 * * ?")
    @Transactional
    public void deleteExpiredOrders() {
        LocalDateTime expirationTime = LocalDateTime.now().minusHours(3);
        orderRepository.deleteByOrderStatusAndOrderedTimeBefore("NOT_PAYED", expirationTime);
    }
}
