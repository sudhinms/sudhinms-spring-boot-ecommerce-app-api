package com.ecommerce.app.EcommerceApp.enums;

public enum PaymentMethod {
    CASH_ON_DELIVERY,
    CREDIT_CARD,
    EMI,
    UPI;
}
