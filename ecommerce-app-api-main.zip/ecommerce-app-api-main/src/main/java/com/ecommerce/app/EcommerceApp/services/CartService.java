package com.ecommerce.app.EcommerceApp.services;

import com.ecommerce.app.EcommerceApp.controllers.CustomerController;
import com.ecommerce.app.EcommerceApp.dto.productDto.CartDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.ProductDetailsDto;
import com.ecommerce.app.EcommerceApp.dto.productDto.ProductDetailsUserView;
import com.ecommerce.app.EcommerceApp.entities.CartDetails;
import com.ecommerce.app.EcommerceApp.entities.ProductDetails;
import com.ecommerce.app.EcommerceApp.entities.UserInfo;
import com.ecommerce.app.EcommerceApp.exceptions.FileReadWriteException;
import com.ecommerce.app.EcommerceApp.exceptions.ProductNotFoundException;
import com.ecommerce.app.EcommerceApp.exceptions.ProductOutOfStockException;
import com.ecommerce.app.EcommerceApp.repositories.CartDetailsRepository;
import com.ecommerce.app.EcommerceApp.repositories.ProductRepository;
import com.ecommerce.app.EcommerceApp.repositories.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class CartService {

    @Autowired
    private ProductService productService;
    @Autowired
    private CartDetailsRepository cartDetailsRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private UserRepository userRepository;

    private long getUserIdWithEmail(String email){
        return userRepository.findByEmail(email).get().getId();
    }
    private byte[] getImage(String imagePath){
        if(Files.exists(Path.of(imagePath))){
            try {
                return Files.readAllBytes(Path.of(imagePath));
            } catch (IOException e) {
                throw new FileReadWriteException(e.getMessage()+"\nCan't read image from : "+imagePath);
            }
        }
        return new byte[]{};
    }

    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<?> addToCart(long id,String email,int quantity) {
        ProductDetails product = productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Requested product with id : " + id + " not found"));
        try {
            if (product == null) {
                throw new ProductNotFoundException("Requested product with id : " + id + " not found");
            }
            if (product.getQuantity() < 1) {
                throw new ProductOutOfStockException("Product is out of stock");
            }
            if (product.getQuantity() < quantity) {
                throw new ProductOutOfStockException("only " + product.getQuantity() + " left");
            }
            List<CartDetails> cartDetailsList = cartDetailsRepository.findAllByUserId(getUserIdWithEmail(email));
            List<CartDetails> existingWithSameId = cartDetailsList.stream()
                    .filter(cartItem -> cartItem.getProductId() == id).toList();
            if (!existingWithSameId.isEmpty()) {
                return new ResponseEntity<>("Item already present in cart..", HttpStatus.FOUND);
            }

            CartDetails cartDetails = new CartDetails();
            cartDetails.setUserId(getUserIdWithEmail(email));
            cartDetails.setProductId(id);
            cartDetails.setQuantity(quantity);
            cartDetailsRepository.save(cartDetails);

            CartDto cartDto = CartDto.builder()
                    .productName(product.getName())
                    .productId(product.getId())
                    .price(product.getPrice())
                    .quantity(quantity)
                    .build();
            if (product.getImagePath() != null) {
                cartDto.setImage(getImage(product.getImagePath()));
            }
            return new ResponseEntity<>(cartDetails, HttpStatus.OK);
        }catch (Exception e){
            throw new ProductOutOfStockException(e.getMessage());
        }
    }

    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<List<CartDto>> getAllItemsInCart(String email){
            List<CartDetails> cartDetailsList = cartDetailsRepository.findAllByUserId(getUserIdWithEmail(email));
            List<CartDto> allItems = cartDetailsList.stream().map(CartDetails::getProductId).toList()
                    .stream().map(productId -> productRepository.findById(productId))
                    .map(productDetails -> {
                        ProductDetails details = productDetails.get();
                        CartDto cartDto = new CartDto();
                        cartDto.setProductId(details.getId());
                        cartDto.setPrice(details.getPrice());
                        cartDto.setProductName(details.getName());
                        if (details.getImagePath() != null) {
                            cartDto.setImage(getImage(details.getImagePath()));
                        }
                        return cartDto;
                    }).toList();
            if (allItems.isEmpty()) {
                throw new ProductNotFoundException("No items in the cart");
            }
            return new ResponseEntity<>(allItems, HttpStatus.OK);
    }

    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<?> deleteFromCart(long id,String email){
        if(cartDetailsRepository.findByProductIdAndUserId(id,getUserIdWithEmail(email))==null){
            throw new ProductNotFoundException("Product with id : "+id+"  not found");
        }
        cartDetailsRepository.deleteByUserIdAndProductId(getUserIdWithEmail(email),id);
        Link link=Link.of("http://localhost:8081/app/home/cart/getAll")
                .withRel("Get_All_Cart_Items");
        return ResponseEntity.status(HttpStatus.OK).body(link);
    }
}
