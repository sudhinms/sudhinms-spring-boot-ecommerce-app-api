package com.ecommerce.app.EcommerceApp.enums;

public enum PaymentStatus {
    PAYED,
    NOT_PAYED,
    CASH_ON_DELIVERY,
    REFUND_REQUEST,
    REFUNDED;
}
